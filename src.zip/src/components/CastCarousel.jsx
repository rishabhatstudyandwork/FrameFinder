import React from "react";
import { useNavigate } from "react-router-dom";

const CastCarousel = ({ cast = [] }) => {
  const navigate = useNavigate();

  if (!Array.isArray(cast) || cast.length === 0) {
    return <p className="text-gray-400">No cast available.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <div className="flex gap-4 pb-4">
        {cast.map((person) => (
          <div
            key={person.id}
            className="min-w-[150px] flex-shrink-0 cursor-pointer hover:scale-105 transition-transform"
            onClick={() => navigate(`/search?q=${encodeURIComponent(person.name)}`)}
          >
            {person.profile_path ? (
              <img
                src={`https://image.tmdb.org/t/p/w300${person.profile_path}`}
                alt={person.name}
                className="w-full h-48 object-cover rounded-lg mb-2"
              />
            ) : (
              <div className="bg-gray-700 w-full h-48 flex items-center justify-center rounded-lg mb-2">
                <span className="text-gray-400 text-sm">No image</span>
              </div>
            )}
            <h3 className="font-semibold truncate">{person.name}</h3>
            <p className="text-gray-400 text-sm truncate">{person.character}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CastCarousel;
