import React from 'react';

const FilterBar = () => {
  return (
    <div className="filter-bar">
      <h2>Filter Bar</h2>
    </div>
  );
};

export default FilterBar;
