import React from 'react';

const ShowDetail = () => {
  return (
    <div className="show-detail">
      <h1>Show Detail</h1>
    </div>
  );
};

export default ShowDetail;
